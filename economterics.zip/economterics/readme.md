Run the Data_precocssing1 python file and you will get filtered_data.csv,and transposed_data.csv as output csv files 
write state in first row and first coloumn in transposed_data.csv file and run the Data_precocssing2 python file 
It will give a merged_data_with_sdp_and_gini.csv as an output csv filed which is our desired merged data 
here we have coloumns as state,district,year,nitrate,SDP and gini index